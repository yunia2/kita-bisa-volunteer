<?php
session_start(); // BOLEH
require('fpdf186/fpdf.php');
include 'koneksi.php';

/* ❌ JANGAN ADA CEK LOGIN DI FILE CETAK ❌ */

/* ======================
   AMBIL DATA FORM
   ====================== */
$id_penugasan = $_POST['id_penugasan'] ?? null;
$id_barang    = $_POST['id_barang'] ?? null;
$jumlah       = $_POST['jumlah'] ?? null;

if (!$id_penugasan || !$id_barang || !$jumlah) {
    exit;
}

/* ======================
   SIMPAN LOGISTIK
   ====================== */
mysqli_query($conn,"
    INSERT INTO logistik (id_penugasan, id_barang, jumlah_keluar)
    VALUES ('$id_penugasan', '$id_barang', '$jumlah')
");

mysqli_query($conn,"
    UPDATE barang
    SET stok = stok - $jumlah
    WHERE id_barang = '$id_barang'
");

/* ======================
   CETAK PDF
   ====================== */
$pdf = new FPDF('L','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',14);
$pdf->Cell(277,10,'LAPORAN PENGELUARAN LOGISTIK',0,1,'C');
$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'No',1,0,'C');
$pdf->Cell(40,10,'Tanggal',1,0,'C');
$pdf->Cell(80,10,'Lokasi Penugasan',1,0,'C');
$pdf->Cell(80,10,'Nama Barang',1,0,'C');
$pdf->Cell(30,10,'Jumlah',1,1,'C');

$pdf->SetFont('Arial','',10);
$no = 1;

$q = mysqli_query($conn,"
    SELECT p.tgl_tugas, l.nama_lokasi, b.nama_barang, lg.jumlah_keluar
    FROM logistik lg
    JOIN penugasan p ON lg.id_penugasan = p.id_penugasan
    JOIN lokasi l ON p.id_lokasi = l.id_lokasi
    JOIN barang b ON lg.id_barang = b.id_barang
    ORDER BY lg.id_logistik DESC
    LIMIT 1
");

while ($r = mysqli_fetch_assoc($q)) {
    $pdf->Cell(10,10,$no++,1,0,'C');
    $pdf->Cell(40,10,$r['tgl_tugas'],1,0,'C');
    $pdf->Cell(80,10,$r['nama_lokasi'],1,0,'L');
    $pdf->Cell(80,10,$r['nama_barang'],1,0,'L');
    $pdf->Cell(30,10,$r['jumlah_keluar'],1,1,'C');
}

$pdf->Output('I','Laporan_Logistik.pdf');
