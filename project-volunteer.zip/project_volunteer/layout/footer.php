    </div> <!-- end page-content -->
  <link rel="stylesheet" href="assets/css/style_relawan.css">

    <footer class="footer">
        <p>©<?= date('Y'); ?> Volunteer Platform</p>
    </footer>
</body>
</html>
