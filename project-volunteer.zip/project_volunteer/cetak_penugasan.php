<?php
require('fpdf186/fpdf.php');
include 'koneksi.php';

/* ======================
   AMBIL DATA FORM
   ====================== */
$id_r = $_POST['relawan'] ?? null;
$id_l = $_POST['lokasi'] ?? null;
$id_b = $_POST['barang'] ?? null;
$jml  = $_POST['jumlah'] ?? null;

if (!$id_r || !$id_l || !$id_b || !$jml) {
    exit('Data tidak lengkap');
}

/* ======================
   SIMPAN DATA
   ====================== */
mysqli_query($conn,"
    INSERT INTO penugasan (id_relawan, id_lokasi, tgl_tugas)
    VALUES ('$id_r','$id_l',NOW())
");

$id_tugas = mysqli_insert_id($conn);

mysqli_query($conn,"
    INSERT INTO logistik (id_penugasan,id_barang,jumlah_keluar)
    VALUES ('$id_tugas','$id_b','$jml')
");

/* ======================
   CETAK PDF
   ====================== */
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();

$pdf->SetFont('Arial','B',14);
$pdf->Cell(190,10,'LAPORAN PENUGASAN RELAWAN',0,1,'C');
$pdf->Ln(5);

$pdf->SetFillColor(230,230,230);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'No',1,0,'C',true);
$pdf->Cell(60,10,'Relawan',1,0,'C',true);
$pdf->Cell(60,10,'Lokasi',1,0,'C',true);
$pdf->Cell(60,10,'Tanggal',1,1,'C',true);

$pdf->SetFont('Arial','',10);

$q = mysqli_query($conn,"
    SELECT r.nama_relawan, l.nama_lokasi, p.tgl_tugas
    FROM penugasan p
    JOIN relawan r ON p.id_relawan=r.id_relawan
    JOIN lokasi l ON p.id_lokasi=l.id_lokasi
    WHERE p.id_penugasan='$id_tugas'
");

$no = 1;
while ($d = mysqli_fetch_assoc($q)) {
    $pdf->Cell(10,10,$no++,1,0,'C');
    $pdf->Cell(60,10,$d['nama_relawan'],1,0);
    $pdf->Cell(60,10,$d['nama_lokasi'],1,0);
    $pdf->Cell(60,10,$d['tgl_tugas'],1,1);
}

$pdf->Output('I','Penugasan.pdf');
