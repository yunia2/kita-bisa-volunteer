<?php
include 'koneksi.php';
?>

<h2>Form Input Penugasan</h2>
  <link rel="stylesheet" href="assets/css/input_tugas.css">

<form method="POST" action="cetak_penugasan.php" target="_blank">
    Relawan:
    <select name="relawan" required>
        <?php
        $res = mysqli_query($conn,"SELECT * FROM relawan");
        while ($row = mysqli_fetch_array($res)) {
            echo "<option value='$row[id_relawan]'>$row[nama_relawan]</option>";
        }
        ?>
    </select><br><br>

    Lokasi:
    <select name="lokasi" required>
        <?php
        $res = mysqli_query($conn,"SELECT * FROM lokasi");
        while ($row = mysqli_fetch_array($res)) {
            echo "<option value='$row[id_lokasi]'>$row[nama_lokasi]</option>";
        }
        ?>
    </select><br><br>

    Barang:
    <select name="barang" required>
        <?php
        $res = mysqli_query($conn,"SELECT * FROM barang");
        while ($row = mysqli_fetch_array($res)) {
            echo "<option value='$row[id_barang]'>$row[nama_barang]</option>";
        }
        ?>
    </select><br><br>

    Jumlah:
    <input type="number" name="jumlah" required><br><br>

    <button type="submit">Simpan & Cetak</button>
</form>
